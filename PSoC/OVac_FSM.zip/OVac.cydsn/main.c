/*******************************************************************************
* File Name: main.c
*
* Version: 2.20
*
* Description:
*   This is a source code for example project of ADC single ended mode.
*
*   Variable resistor(pot) is connected to +ve input of ADC using the I/O pin.
*   P0.0. When voltage to positive terminal of ADC is 0, the output displayed
*   on the LCD pannel is 0x0000. As voltage on positive terminal goes on
*   increasing, the  converted value goes on increasing from 0x0000 and reaches
*   0xFFFF when voltage becomes 1.024V. Futher increase in voltage value,
*   doesn't cause any changes to values displayed in the LCD.
*
* Hardware Connections:
*  Connect analog input from Variable resistor to port P0[0] of DVK1 board.
*
********************************************************************************
* Copyright 2012-2015, Cypress Semiconductor Corporation. All rights reserved.
* This software is owned by Cypress Semiconductor Corporation and is protected
* by and subject to worldwide patent and copyright laws and treaties.
* Therefore, you may use this software only as provided in the license agreement
* accompanying the software package from which you obtained this software.
* CYPRESS AND ITS SUPPLIERS MAKE NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* WITH REGARD TO THIS SOFTWARE, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT,
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*******************************************************************************/

#include <project.h>
#include <mpu6050.h>
#include <stdio.h>
#include <string.h>
#include <FS.h>
#include "LiquidCrystal_I2C.h"
#include "functions.h"

#define MPU6050 
#define LCD
//#define SD

#define MA_WINDOW 15                    // Number of samples in the moving average window.
#define BOT_THRESHOLD 20000             // Z-Aacceleration threshold for transition into LANDED state.
#define WAIT_TIME 1000                  // Number of ISR calls until transition into DESCENDING state.
#define DATA_TIME 5000                  // Number of ISR calls until transition into WAIT_TO_LAUNCH state.


/*State Declarations*/
enum STATES{
SYSTEM_CHECK, 
WAIT_TO_LAUNCH,
DESCENDING,
LANDED,
RESURFACE,
TRANSMIT,
ERROR
};


uint32_t Addr = 0x3F;                       // I2C address of LCD.
long id = 1;                                // Interrupt count.
uint8_t landing_count = 0;                  // counting variable for the landing state

long sum = 0;                               // Sum of accelerometer values. 
int16_t average = 0;                        // Moving average variable.
bool collect_flag = 0;                      // flag indicating when to record acceleration sample.
bool wait_flag = 0;                         // flag indicating when to increment interrupt counter.
bool ready_to_suck = 0;                     // flag saying conditions met for collecting samples
enum STATES STATE = SYSTEM_CHECK;           // Set initial state. 
char sdFile[9] = "data.txt";

/*******************************************************************************
* Function Name: main
********************************************************************************
*
* Summary:
*  main() performs following functions:
*  1: Initializes the LCD.
*  2: Initializes timer module and sampling interrupt.
*  3: Initializes MPU6050 Accelerometer/Gyroscope module.
*  4: Samples Z-axis acceleration data from module @ 500hz.
*  5: Computes moving average of Z-axis acceleration values.
*  6: Transitions from DESCENDING to LANDED state when sudden acceleration occurs
*     (ie. moving average > 200000).
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/

/* Sampling ISR */
CY_ISR (Sample_ISR_Handler){
    
    Sample_Timer_STATUS;                        //Clears interrupt by accessing timer status register
    if (STATE != WAIT_TO_LAUNCH && STATE != ERROR){ 
        collect_flag = 1;
    }
    else
        wait_flag = 1;
    
}

/* Landing state ISR for checking if ok to collect and collecting itself */
CY_ISR (Solenoid_ISR_Handler){
    
    Solenoid_Timer_STATUS;                        //Clears interrupt by accessing timer status register
    landing_count++;
    if (landing_count == 10 && ready_to_suck == 0){ // reached 5 seconds of stable conditions, set flag to indicate so
        ready_to_suck = 1;
        landing_count = 0;
    }
    
}

int main()
{
    uint8_t output;
    char buf[50];                               //just to hold text values in for writing to UART
    char curState[14] = "SYSTEM_CHECK  ";
    int16_t ax, ay, az, i;
    //int16_t gx, gy, gz;
    int16_t z_offset = 0;
    char volname[7] = "volume";
    FS_FILE *file;
    
    /* Start the components */
    CYGlobalIntEnable;                          //enable global interrupts
    I2C_Master_Start(); 
    ADC_Start();
    Sample_Timer_Start();                       //start timer module
    Sample_ISR_StartEx(Sample_ISR_Handler);     //reference ISR function
    
    #ifdef LCD
        LiquidCrystal_I2C_init(Addr,16,2,0);        //initialize I2C communication with LCD
        begin(); 
    
    #endif
   
    /* initialize MPU6050 */
    #ifdef MPU6050
        MPU6050_init();    
	    MPU6050_initialize(); 
    #endif
        
    #ifdef LCD
        /* Startup Display */
        LCD_print("PSoC 5LP: O-Vac");
        setCursor(0,1);
        LCD_print("I2C Working");
    
        /* Display the current State */
        setCursor(0,0);    
        clear();
        LCD_print("state: SYSTEM_CHECK");
    
        CyDelay(1000u);   
        clear();
    #endif
    
    #ifdef SD
        if (Initialize_SD_Card(&sdFile[0],&volname[0], file))
            LCD_print("SD card initialization failure");
    #endif 
    
    /* Start the ADC conversion */
    ADC_StartConvert();
    
    STATE = WAIT_TO_LAUNCH;
    
    for(;;)
    {       
        if(ADC_IsEndConversion(ADC_RETURN_STATUS))
        {
            output = ADC_GetResult8(); 
        }
        
        /* Display Z-Acceleration */
        //clear();
        az = MPU6050_getAccelerationZ();
       // I2C_LCD_print(1,0, id ,0,average);                                //print Interrupt count and Z-Acceleration
        if(collect_flag == 1){          
                    if (id < MA_WINDOW)
                        sum += az;     
                    else if(id == MA_WINDOW){
                        sum += az;
                        average = sum / MA_WINDOW;                            //compute baseline average
                    }
                    else{
                        average = ComputeMA(average, MA_WINDOW, az);
                    }
                    id++;
                collect_flag = 0;
            }
        /* State Machine */
        switch (STATE){
            
            case WAIT_TO_LAUNCH:    
                if(wait_flag == 1){
                    id++;
                    if(id >= WAIT_TIME){
                        STATE = DESCENDING;
                        #ifdef LCD
                            setCursor(0,0);
                            clear();
                            LCD_print("STATE: DESCENT");
                        #endif           
                        Solenoid_1_Write(0);
                        id = 0;
                        LED4_Write(0);                                      // turn the LED off 
                    }
                    wait_flag = 0; 
                }
                break;
                
            case DESCENDING:
                if (average > BOT_THRESHOLD) {
                    LED4_Write(1);                                          //turn LED on                        
                    STATE = LANDED;                                 //Switch to LANDED state 
                    #ifdef LCD
                        setCursor(0,0);
                        clear();
                        LCD_print("STATE: LANDED");  
                        I2C_LCD_print(1,0, id ,0,average);
                    #endif
                    Solenoid_1_Write(1);
                    id=0;                                                   //reset sample counter
                    sum = 0;
                    average = 0;
                    CyDelay(500u);
                    Solenoid_Timer_Start();                     // half sec solenoid timer 
                    Solenoid_isr_StartEx(Solenoid_ISR_Handler);
                    landing_count = 0;
                    ready_to_suck = 0;
                }
           
                /*if desired amount of samples have been collected, switch states*/
                if(id >= DATA_TIME){     
                    LED4_Write(1);                                         //turn LED on
                    STATE = WAIT_TO_LAUNCH;                               //Switch to Waiting state    
                    #ifdef LCD
                        setCursor(0,0);
                        clear();
                        LCD_print("STATE: WAIT");  
                    #endif
                    id=0;                                                  //reset sample counter
                    sum = 0;                                               //reset sum 
                    average = 0;                      
                }
                break;
                
            case LANDED:
                // if pressure stays same for 5 seconds, and no tipping detected
                // also no big acceleration, it is ready to collect
                /*if (pressure > test_pressure + some margin of error)
                       STATE = DESCENDING;
                */
                   
                if (average > BOT_THRESHOLD - 1000){
                    #ifdef LCD
                        setCursor(0,0);
                        clear();
                        LCD_print("STATE: DESCENT-from");  
                    #endif
                    STATE = DESCENDING;
                    average = 0;
                    id = 0;
                    sum = 0;
                    ready_to_suck = 0;
                    landing_count = 0;
                }
                
                if (ready_to_suck && (landing_count % 2) == 0 && landing_count > 0){
                    #ifdef LCD
                        setCursor(0,0);
                        clear();
                        LCD_print("STATE: LANDED-sucking");  
                    #endif
//                    if (Solenoid_1_Read())
//                        Solenoid_1_Write(0);
//                    else 
                        //Solenoid_1_Write(1);
                        if (landing_count >= 10){
                            STATE = RESURFACE;
                            #ifdef LCD
                                setCursor(0,0);
                                clear();
                                LCD_print("STATE: RESURFACE");  
                            #endif
                            average = 0;
                            id = 0;
                            sum = 0;
                            ready_to_suck = 0;
                            landing_count = 0;
                        }     
                }
                
                break;
                
            case RESURFACE:
                if (average > BOT_THRESHOLD){
                    #ifdef LCD
                        setCursor(0,0);
                        clear();
                        LCD_print("STATE: TRANSMIT");  
                    #endif
                    STATE = TRANSMIT;
                    average = 0;
                    id = 0;
                    sum = 0;
                    ready_to_suck = 0;
                    landing_count = 0;
                }
                break;
                
            case TRANSMIT:
                if (average > BOT_THRESHOLD - 1000){
                    #ifdef LCD
                        setCursor(0,0);
                        clear();
                        LCD_print("STATE: RESURF-from");  
                    #endif
                    STATE = RESURFACE;
                    average = 0;
                    id = 0;
                    sum = 0;
                    ready_to_suck = 0;
                    landing_count = 0;
                }
      
                if (ready_to_suck && (landing_count % 2) == 0 && landing_count > 0){
                    #ifdef LCD
                        setCursor(0,0);
                        clear();
                        LCD_print("STATE: READY to ");
                        setCursor(0,1);
                        LCD_print("transmit");  
                    #endif                 
                }
                break;
                
            case ERROR:
                break;
                
            default:
                break;
        
        }
        
    }
}

/* [] END OF FILE */
