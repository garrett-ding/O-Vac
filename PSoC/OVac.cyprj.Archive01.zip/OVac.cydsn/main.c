/*******************************************************************************
* File Name: main.c
*
* Version: 2.20
*
* Description:
*   This is a source code for example project of ADC single ended mode.
*
*   Variable resistor(pot) is connected to +ve input of ADC using the I/O pin.
*   P0.0. When voltage to positive terminal of ADC is 0, the output displayed
*   on the LCD pannel is 0x0000. As voltage on positive terminal goes on
*   increasing, the  converted value goes on increasing from 0x0000 and reaches
*   0xFFFF when voltage becomes 1.024V. Futher increase in voltage value,
*   doesn't cause any changes to values displayed in the LCD.
*
* Hardware Connections:
*  Connect analog input from Variable resistor to port P0[0] of DVK1 board.
*
********************************************************************************
* Copyright 2012-2015, Cypress Semiconductor Corporation. All rights reserved.
* This software is owned by Cypress Semiconductor Corporation and is protected
* by and subject to worldwide patent and copyright laws and treaties.
* Therefore, you may use this software only as provided in the license agreement
* accompanying the software package from which you obtained this software.
* CYPRESS AND ITS SUPPLIERS MAKE NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* WITH REGARD TO THIS SOFTWARE, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT,
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*******************************************************************************/

#include <project.h>
#include <mpu6050.h>
#include <stdio.h>
#include <string.h>
#include <FS.h>
#include "LiquidCrystal_I2C.h"
#include "functions.h"

//#define MPU6050 
enum STATES{
SYSTEM_CHECK, 
WAIT_TO_LAUNCH,
DESCENDING,
LANDED,
RESURFACE,
TRANSMIT,
ERROR
};

//#define SHUTDOWN 5

uint32_t Addr = 0x3F;
enum STATES MY_MACHINE = SYSTEM_CHECK;
char sdFile[9] = "Game.txt";

/*******************************************************************************
* Function Name: main
********************************************************************************
*
* Summary:
*  main() performs following functions:
*  1: Initializes the LCD
*  2: Starts ADC
*  3: Starts ADC converstion.
*  4: Gets the converted result and displays it in LCD.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
int main()
{
    int32 output;
    char buf[50]; //just to hold text values in for writing to UART
    char curState[14] = "SYSTEM_CHECK  ";
    int16_t ax, ay, az, i;
    int16_t gx, gy, gz;
    /* Start the components */
    CYGlobalIntEnable; 
    I2C_Master_Start();
    LCD_Start();
    ADC_Start();
    
    FS_FILE * pFile;
    /* Initialize file system */
    FS_Init();
    
    /* Create specific file for modification */
    pFile = FS_FOpen(sdFile, "w");
    FS_FClose(pFile);
    
    #ifdef MPU6050
    MPU6050_init();
	MPU6050_initialize();
    #endif
    
    LiquidCrystal_I2C_init(Addr,16,2,0);
    begin();
    
    LCD_print("PSoC 5LP: O-Vac");
    setCursor(0,1);
    LCD_print("I2C Working");
    
    //LCD_ClearDisplay();
    
    CyDelay(1000u);
    clear();
    /* Start the ADC conversion */
    ADC_StartConvert();
    
    /* Display the value of ADC output on LCD */
    LCD_Position(0u, 0u);
    LCD_PrintString("MPU6050");
    LED4_Write(1);
    setCursor(0,0);
    
    LCD_print(curState);
    I2C_LCD_print(1,0, 1600 ,444 ,4234);
    
    for(;;)
    {       
        if(ADC_IsEndConversion(ADC_RETURN_STATUS))
        {
            output = ADC_GetResult32();
        }
        switch(MY_MACHINE){
            case SYSTEM_CHECK:
            strcpy(curState,"SYSTEM_CHECK   ");
            if(output>6000){
            MY_MACHINE=WAIT_TO_LAUNCH;
            }else{
            setCursor(0,0);
            LCD_print(curState);
            I2C_LCD_print(1,0, output ,444 ,4234);    
            }
            //add code
            break;
            
            case WAIT_TO_LAUNCH:
            strcpy(curState,"WAIT_TO_LAUNCH   ");
            if(output<6000){
            MY_MACHINE=SYSTEM_CHECK;
            }else if(output>12000){
            MY_MACHINE=DESCENDING;
            }else{
                setCursor(0,0);
                LCD_print(curState);
                I2C_LCD_print(1,0, output ,444 ,4234);  
            }
            break;
            
            case DESCENDING:
            strcpy(curState,"DESCENDING    ");
            if(output<12000){
            MY_MACHINE=WAIT_TO_LAUNCH;
            }else if(output>18000){
            MY_MACHINE=LANDED;
            }else{
                setCursor(0,0);
                LCD_print(curState);
            I2C_LCD_print(1,0, output ,444 ,4234);  
            }
            break;
            
            case LANDED:
            strcpy(curState,"LANDED    ");
            if(output<18000){
            MY_MACHINE=DESCENDING;
            }else if(output>24000){
            MY_MACHINE=RESURFACE;
            }else{
                setCursor(0,0);
                LCD_print(curState);
            I2C_LCD_print(1,0, output ,444 ,4234);  
            }
            break;
            
            case RESURFACE:
            strcpy(curState,"RESURFACE   ");
            if(output<24000){
            MY_MACHINE=LANDED;
            }else if(output>30000){
            MY_MACHINE=TRANSMIT;
            }else{
                setCursor(0,0);
                LCD_print(curState);
            I2C_LCD_print(1,0, output ,444 ,4234);  
            }
            break;
            
            case TRANSMIT:
            strcpy(curState,"TRANSMIT   ");
            if(output<30000){
            MY_MACHINE=RESURFACE;
            }else{
                setCursor(0,0);
                LCD_print(curState);
            I2C_LCD_print(1,0, output ,444 ,4234);  
            }
            break;
            
            default:
            break;
        }
    }
}


/* [] END OF FILE */
