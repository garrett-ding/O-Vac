/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "project.h"
#include <FS.h>

#ifndef __functions_h
#define __functions_h
    
    int16_t ComputeMA(int16_t avg, int16_t n, int16_t sample);
    int Initialize_SD_Card(char *filename, char *volname, FS_FILE *file);
    void I2C_LCD_print(uint8_t row, uint8_t column, uint16_t ax, uint16_t ay,uint16_t az);
    
    
#endif    


/* [] END OF FILE */
