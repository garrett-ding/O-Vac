/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include <project.h>
#include <mpu6050.h>
#include <stdio.h>
#include <string.h>
#include <FS.h>
#include "LiquidCrystal_I2C.h"
#include "functions.h"

#define MA_WINDOW 15                    // Number of samples in the moving average window
#define BOT_THRESHOLD 20000

//#define MPU6050 
enum STATES{ 
WAIT_TO_LAUNCH,
DESCENDING,
LANDED,
RESURFACE,
TRANSMIT,
ERROR
};

CY_ISR_PROTO(pulse);
CY_ISR_PROTO(sample);

//#define SHUTDOWN 5

uint32_t Addr = 0x3F;
enum STATES MY_MACHINE = WAIT_TO_LAUNCH;
char sdFile[9] = "Game.txt";
int dataflag = 0, pulseflag = 0;

int main(void)
{
    char sdVolName[10];
    FS_FILE * pFile = NULL;
    int32 output = 0;
    char buf[50]; //just to hold text values in for writing to UART
    char curState[14] = "SYSTEM_CHECK  ";
    Initialize_SD_Card(&sdFile[0], &sdVolName[0], pFile); // in functions.c
    int16_t ax, ay, az, i;
    int16_t gx, gy, gz, average = 0;
    long id = 1, sum = 0;
    CyDelay(2000u);
    CyGlobalIntEnable; /* Enable global interrupts. */
    LCD_Start(); // LCD start
    Sample_Start(); // sampler timer 
    ADC_Start();
    I2C_Master_Start();
    Solenoid_StartEx(pulse); // ISRs start
    sampler_StartEx(sample);

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    #ifdef MPU6050
    MPU6050_init();
    MPU6050_initialize();
    #endif
    
    LiquidCrystal_I2C_init(Addr,16,2,0);
    begin();
    
    LCD_print("PSoC 5LP: O-Vac");
    setCursor(0,1);
    LCD_print("I2C Working");
    
    //LCD_ClearDisplay();
    
    CyDelay(1000u);
    clear();
    /* Start the ADC conversion */
    ADC_StartConvert();
    
    /* Display the value of ADC output on LCD */
    LCD_Position(0u, 0u);
    LCD_PrintString("MPU6050");
    LED4_Write(1);
    setCursor(0,0);
    
    LCD_print(curState);
    I2C_LCD_print(1,0, 1600 ,444 ,4234);
    
    for(;;)
    {
        if(ADC_IsEndConversion(ADC_RETURN_STATUS))
        {
            output = ADC_GetResult32();
        }
        if (dataflag){
            if (id<MA_WINDOW)
              sum += az;     
            else if(id == MA_WINDOW){
              sum += az;
              average = sum/MA_WINDOW;  //compute baseline average
            }
            else
              average = ComputeMA(average, MA_WINDOW, az);
            id++;
            dataflag = 0;
        }
        
    /** ***********  State machine **************************************/   
        switch(MY_MACHINE){
            case WAIT_TO_LAUNCH:
                strcpy(curState,"WAIT_TO_LAUNCH   ");
                if(average > 15500){
                    MY_MACHINE=DESCENDING;
                    id=0; 
                    sum = 0;//reset sample counter
                    average = 0;
                }else{
                    setCursor(0,0);
                    LCD_print(curState);
                    I2C_LCD_print(1,0, output ,444 ,4234);  
                }
                break;
            
            case DESCENDING:
                strcpy(curState,"DESCENDING    ");
                if(average > BOT_THRESHOLD){
                    MY_MACHINE=LANDED;
                    id=0; 
                    sum = 0;//reset sample counter
                    average = 0;
                    Solenoid_timer_Start();
                }else{
                    setCursor(0,0);
                    LCD_print(curState);
                    I2C_LCD_print(1,0, output ,444 ,4234);  
                }
                break;
            
            case LANDED:
                strcpy(curState,"LANDED    ");
                if(pulseflag > 10){
                    MY_MACHINE=RESURFACE;
                    Solenoid_timer_Stop();
                }else{
                    // flip solenoid
                    setCursor(0,0);
                    LCD_print(curState);
                    I2C_LCD_print(1,0, output ,444 ,4234);  
                }
                break;
                
            case RESURFACE:
                strcpy(curState,"RESURFACE   ");
                if(output>30000){ // need to determine when at surface
                    MY_MACHINE=TRANSMIT;
                }else{
                    setCursor(0,0);
                    LCD_print(curState);
                    I2C_LCD_print(1,0, output ,444 ,4234);  
                }
                break;
            
            case TRANSMIT: // and what we do at surface
                strcpy(curState,"TRANSMIT   ");
                if(output<30000){
                    MY_MACHINE=RESURFACE;
                }else{
                    setCursor(0,0);
                    LCD_print(curState);
                    I2C_LCD_print(1,0, output ,444 ,4234);  
                }
                break;
            
            default:
                break;
        }
    }
}

CY_ISR(pulse){
    pulseflag++;
    /* Clear Timer bit to reset counter */
    Solenoid_timer_STATUS;
}

CY_ISR(sample){
    dataflag = 1;
    Sample_STATUS;
}
/* [] END OF FILE */
